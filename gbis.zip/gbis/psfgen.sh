#!/bin/csh
/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL 
topology /usr/local/src/c27b2/toppar_c31b/non_charmm/amber99sb_star_ildn.rtf
segment PROT {
pdb mut.pdb
}
coordpdb mut.pdb PROT
guesscoord
writepsf output/sys.psf
writepdb output/sys.pdb
ENDMOL
cp output/sys.pdb output/sys_in.pdb
cp output/sys.psf output/sys_in.psf

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 min_GBSI.namd 

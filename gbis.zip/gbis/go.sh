#!/bin/csh 
/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 min_GBSI.namd >& minimize_mut.log 
#cp output/mynewpdb.pdb output/sys_min.pdb
#cp output/sys_min.pdb output/sys_in.pdb
#/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 equi_GBSI.namd >& equilibration_mut.log
#cp output/sys_out.coor output/sys_start_dyn.coor
#cp output/sys_out.vel output/sys_start_dyn.vel
#cp output/sys_out.dcd output/sys_start_dyn.dcd
#cp output/sys_out.xsc output/sys_start_dyn.xsc
#cp output/sys_start_dyn.coor output/sys_in.pdb
#cp output/sys_start_dyn.vel output/sys_in.vel
#cp output/sys_start_dyn.xsc output/sys_in.xsc
#/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 md_GBSI.namd >& production_mut.log

mol new mypsffile.psf
mol addfile mybincoords.coor
set sel [atomselect top all]
$sel writepdb mynewpdb.pdb 

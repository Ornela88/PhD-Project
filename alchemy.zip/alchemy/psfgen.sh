#!/bin/csh
/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL 
topology /usr/local/src/c27b2/toppar_c31b/non_charmm/amber99sb_star_ildn.rtf
segment PROA {
pdb atoh1_model_A.pdb
}
coordpdb atoh1_model_A.pdb PROA
guesscoord
writepsf output/proa.psf
writepdb output/proa.pdb
ENDMOL

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL 
topology /usr/local/src/c27b2/toppar_c31b/non_charmm/amber99sb_star_ildn.rtf
segment PROB {
pdb atoh1_model_B.pdb
}
coordpdb atoh1_model_B.pdb PROB
guesscoord
writepsf output/prob.psf
writepdb output/prob.pdb
ENDMOL

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL 
topology /usr/local/src/c27b2/toppar_c31b/non_charmm/amber99sb_star_ildn.rtf
topology ./amber99sb_star_ildn_hybrid.rtf
segment PROB {
pdb atoh1_model_BX.pdb
}
coordpdb atoh1_model_BX.pdb PROB
guesscoord
writepsf output/probx.psf
writepdb output/probx.pdb
ENDMOL

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL
topology /usr/local/src/c27b2/toppar_c31b/non_charmm/amber99sb_star_ildn.rtf
segment DNAE {
pdb atoh1_model_E.pdb
}
coordpdb atoh1_model_E.pdb DNAE
patch DOA DNAE:2
patch DOG DNAE:3
patch DOG DNAE:4
patch DOC DNAE:5
patch DOC DNAE:6
patch DOA DNAE:7
patch DOC DNAE:9
patch DOG DNAE:11
patch DOG DNAE:12
patch DOC DNAE:14
patch DOC DNAE:15
guesscoord
writepsf output/dnae.psf
writepdb output/dnae.pdb
ENDMOL

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL
topology /usr/local/src/c27b2/toppar_c31b/non_charmm/amber99sb_star_ildn.rtf
segment DNAF {
pdb atoh1_model_F.pdb
}
coordpdb atoh1_model_F.pdb DNAF
patch DOA5 DNAF:20
patch DOG DNAF:21
patch DOG DNAF:22
patch DOA DNAF:23
patch DOC DNAF:24
patch DOC DNAF:25
patch DOA DNAF:26
patch DOG DNAF:27
patch DOA DNAF:28
patch DOG DNAF:30
patch DOG DNAF:31
patch DOC DNAF:32
patch DOC DNAF:33
patch DOA3 DNAF:35
guesscoord
writepsf output/dnaf.psf
writepdb output/dnaf.pdb
ENDMOL

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL 
readpsf output/proa.psf
coordpdb output/proa.pdb
readpsf output/prob.psf
coordpdb output/prob.pdb
readpsf output/dnae.psf
coordpdb output/dnae.pdb
readpsf output/dnaf.psf
coordpdb output/dnaf.pdb
writepsf output/cplx.psf
writepdb output/cplx.pdb
ENDMOL

/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/psfgen << ENDMOL 
readpsf output/proa.psf
coordpdb output/proa.pdb
readpsf output/probx.psf
coordpdb output/probx.pdb
readpsf output/dnae.psf
coordpdb output/dnae.pdb
readpsf output/dnaf.psf
coordpdb output/dnaf.pdb
writepsf output/cplxx.psf
writepdb output/cplxx.pdb
ENDMOL


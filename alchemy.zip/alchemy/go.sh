#!/bin/csh 
#split_pdb_chains ATOH1_wt.pdb atoh1_model
#pdb2pqr --ff=AMBER atoh1_model_A.pdb atoh1_model_A.pqr --chain
#bluues_new_2 atoh1_model_A.pqr atoh1_model_A -pka
#sed "s/HIS/HIE/g" atoh1_model_A.pdb > tmp.pdb
#mv tmp.pdb atoh1_model_A.pdb
#pdb2pqr --ff=AMBER atoh1_model_B.pdb atoh1_model_B.pqr --chain
#bluues_new_2 atoh1_model_B.pqr atoh1_model_B -pka
#sed "s/HIS/HIE/g" atoh1_model_B.pdb > tmp.pdb
#mv tmp.pdb atoh1_model_B.pdb
#sed "s/ARG B   3/R2G B   3/g" atoh1_model_B.pdb > atoh1_model_BX.pdb
#sed "s/ DA/ADE/g" atoh1_model_E.pdb | sed "s/ DC/CYT/g" | sed "s/ DG/GUA/g" | sed "s/ DT/THY/g" | sed "s/OP1/O1P/g" | sed "s/OP2/O2P/g" > tmp.pdb
#mv tmp.pdb atoh1_model_E.pdb
#sed "s/ DA/ADE/g" atoh1_model_F.pdb | sed "s/ DC/CYT/g" | sed "s/ DG/GUA/g" | sed "s/ DT/THY/g" | sed "s/OP1/O1P/g" | sed "s/OP2/O2P/g" > tmp.pdb
#mv tmp.pdb atoh1_model_F.pdb
#./psfgen.sh
#vmd -dispdev none << EOF >& vmd.log
#package require solvate
#solvate output/cplxx.psf output/cplxx.pdb -t 12.0 -o output/cplxx_solv
#package require autoionize
 #autoionize -psf output/cplxx_solv.psf -pdb output/cplxx_solv.pdb -sc 0.15 -o output/sys
#measure minmax [atomselect top all]
#EOF
#exit
sed "s/OH2  OT/OH2  OW/g" output/sys.psf | sed "s/H1   HT/H1   HW/g" | sed "s/H2   HT/H2   HW/g" | sed "s/SOD/IP /g" | sed "s/CLA/Cl /g"> tmp.psf
cp tmp.psf output/sys.psf
cp output/sys.psf output/sys_in.psf
cp output/sys.pdb output/sys_in.pdb
#charmrun /usr/local/bin/namd2 +p8 minimize.conf >& minimize.log 
/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 minimize.conf >& minimize.log 
cp output/sys_out.coor output/sys_min.pdb
exit
cp output/sys_min.pdb output/sys_in.pdb
/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 +p8 equilibration.conf >& equilibration.log 
cp output/sys_out.coor output/sys_start_dyn.coor
cp output/sys_out.vel output/sys_start_dyn.vel
cp output/sys_out.dcd output/sys_start_dyn.dcd
cp output/sys_out.xsc output/sys_start_dyn.xsc
cp output/sys_start_dyn.coor output/sys_in.pdb
cp output/sys_start_dyn.vel output/sys_in.vel
cp output/sys_start_dyn.xsc output/sys_in.xsc
cp output/cplx_R3BG.fep output/sys_in.fep
/usr/local/src/NAMD_2.13_Linux-x86_64-multicore/namd2 +p8 production.conf >& production.log
